/* 
* @Author: anchen
* @Date:   2016-06-18 11:02:36
* @Last Modified by:   anchen
* @Last Modified time: 2016-06-23 15:56:03
*/

$(document).ready(function(){
    
    // 引入公共头部
    $('#header').load('dlzc_header_footer.html .header_wrap');
    //引入公共footer
    $('#footer').load('dlzc_header_footer.html .footer_wrap');

    //点击切换登录方式
    $('.li_left').click(function(event) {
        $('.sjdt').css('display', 'none');
        $('.putong').css('display', 'block');
        $(this).css('border-bottom', '1px solid #ff8601');
        $(this).next('li').css('border-bottom', '1px solid #d7d7d7');
    });
    $('.li_right').click(function(event) {
        $('.sjdt').css('display', 'block');
        $('.putong').css('display', 'none');
        $(this).css('border-bottom', '1px solid #ff8601');
        $(this).prev('li').css('border-bottom', '1px solid #d7d7d7');
    });
    var user=$.cookie('user');
    var password=$.cookie('password');
    //alert(user+'&&'+password)
    $('.pt_t input').val(user);
    $('.pt_b input').val(password);

    $('.tz input[type=submit]').click(function(event) {
        if($('.pt_t input').val() != '' && $('.pt_b input').val()!=''){
            //$.cookie('user',null);
            $.cookie('password',null);
            $.cookie('userName',user,{path:'/'})
            window.location.href="../index.html";
        }
    });

































































});
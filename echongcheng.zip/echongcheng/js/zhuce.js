/* 
* @Author: anchen
* @Date:   2016-06-17 16:27:30
* @Last Modified by:   anchen
* @Last Modified time: 2016-06-23 21:08:29
*/

$(function(){
    // 引入公共头部
    $('#header').load('dlzc_header_footer.html .header_wrap');
    //引入公共footer
    $('#footer').load('dlzc_header_footer.html .footer_wrap');
    
    //focus事件
    var $tips_user=$('input[name=user]').next('i').text();
    var $tips_psw=$('input[name=password]').next('i').text();
    var $tips_psw2=$('input[name=psw2]').next('i').text();
    var $tips_num=$('input[name=phonenum]').next('i').text();
    var $tips_yzm=$('input[name=yanzheng]').next('i').text();
    $('form div input').focus(function(event) {
        //当前input后的提示换背景及内容
        
        if($(this).attr('name')=='user'){
            $(this).next('i').text($tips_user);
            $(this).next('i').css({
                'background-image':'url(../images/onFocus.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
        }else if($(this).attr('name')=='password'){
            $('.psw_tips').css('display', 'block');
            $(this).next('i').css({
                'background-image':'url(../images/onFocus.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
            $(this).next('i').text($tips_psw);
        }else if($(this).attr('name')=='psw2'){
            $(this).next('i').text($tips_psw2);
            $(this).next('i').css({
                'background-image':'url(../images/onFocus.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
        }else if($(this).attr('name')=='phonenum'){
            $(this).next('i').text($tips_num);
            $(this).next('i').css({
                'background-image':'url(../images/onFocus.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
        }else if($(this).attr('name')=='yanzheng'){
            $(this).next('i').text($tips_yzm);
            //alert(1)
            $(this).next().next('i').css({
                'background-image':'url(../images/onFocus.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
        }
    });
    //input失去焦点事件
    //判断用户名：
    $('input[name=user]').blur(function(event) {
        var str=$(this).val();
        //用户名：4-20位英文、数字、下划线或组合（不能以数字、下划线开头）
        var reg=/^[a-zA-z][a-zA-Z0-9_]{3,19}$/;
        if(reg.test(str)){
            //满足正则后，测试是否满足服务器要求（通过ajax）
            $.ajax({
                url:'http://datainfo.duapp.com/shopdata/userinfo.php',
                type:'POST',
                dataType:'text',
                data:{
                    'status':'register',
                    'userID':$('input[name=user]').val(),
                    'password':$('input[name=password]').val()
                },
                success:function(res){
                    //alert(res)    //1
                    //console.log(this)     //ajax
                    if(res==0){
                        //alert(0)
                        $('input[name=user]').next('i').text('该名称已被使用，请重新输入');
                        $('input[name=user]').next('i').css({
                            'background-image':'url(../images/onError.gif)',
                            'background-position':'left'+' '+'center',
                            'background-repeat':'no-repeat'
                        });
                    }else if(res==2){
                        //alert(2)
                        $('input[name=user]').next('i').text('数据库报错');
                        $('input[name=user]').next('i').css({
                            'background-image':'url(../images/onError.gif)',
                            'background-position':'left'+' '+'center',
                            'background-repeat':'no-repeat'
                        });
                    }else if(res==1){
                        //alert(1)
                        $('input[name=user]').next('i').text('该账号可以注册');
                        $('input[name=user]').next('i').css({
                            'background-image':'url(../images/onCorrect.gif)',
                            'background-position':'left'+' '+'center',
                            'background-repeat':'no-repeat'
                        });
                    }
                }
            });
        }else{
            //alert('输入错误')
            $('input[name=user]').next('i').css({
                'background-image':'url(../images/onError.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            })
            $('input[name=user]').next('i').text('4-20位中英文、数字、下划线或组合');
        }
    });

    
    //判断第一次密码输入   分为三个等级：弱、中、强
    //通过按键事件判断安全等级
    $('input[name=password]').keyup(function(event) {
        var str=$(this).val();
        if(str.length>=6 && str.length<10){
            $('.psw_tips span').find('strong').stop().animate({'width':'0px'},1000).queue(function(){
                $('.psw_tips span').find('strong').text('')
            });
            $('.psw_tips span:eq(1)').find('strong').stop().animate({'width':'83px'},1000).queue(function(){
                $('.psw_tips span:eq(1)').find('strong').text('中');
            })
        }else if(str.length>=10 && str.length<=16){
            //先清空
            $('.psw_tips span').find('strong').stop().animate({'width':'0px'},1000).queue(function(){
                $('.psw_tips span').find('strong').text('')
            });
            $('.psw_tips span:eq(1)').find('strong').css('width', '83px').text('中');
            $('.psw_tips span:eq(2)').find('strong').stop().animate({'width':'83px'},1000).queue(function(){
                $('.psw_tips span:eq(2)').find('strong').text('强');
            })
        }
    });
    

    //判断第一次输入密码 是否符合格式要求    通过失去焦点事件
    $('input[name=password]').blur(function(event) {
        var str=$(this).val();
        //4-16位字符
        var reg=/^[\w]{4,16}$/;
        /*var reg_Num=/^\d{4,16}$/;   //验证纯数字
        var reg_Eng=/^[a-zA-z]{4,16}$/;     //验证纯字母
        var reg_Fh=/^$/；
        var reg_ne=/^[\da-zA-Z]*\d+[a-zA-Z]+[\da-zA-Z]*{4,16}$/;  //字母、数字组合*/
        //console.log(str.length)
        if(reg.test(str)){
            //alert(1)
            $(this).next('i').css({
                'background-image':'url(../images/onCorrect.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
            $(this).next('i').text('密码合法');
        }else{
            $(this).next('i').css({
                'background-image':'url(../images/onError.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
            $(this).next('i').text('密码不符规则');
            $('.psw_tips span').find('strong').css('width', '0px').text('');
        }
    });

    //判断第二次密码输入
    $('.psw_input2 input').blur(function(){
        if($(this).val()==$('input[name=password]').val()){
            $(this).next('i').css({
                'background-image':'url(../images/onCorrect.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
            $(this).next('i').text('密码一致');
        }else{
            $(this).next('i').css({
                'background-image':'url(../images/onError.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
            $(this).next('i').text('2次密码不一致');
        }
    });

    //判断手机号 通过失去焦点事件
    //手机号码正则：/^(13[0-9]|14[0-9]|15[0-9]|18[0-9])\d{8}$/i
    $('input[name=phonenum]').blur(function(event) {
        var str=$(this).val();
        var reg=/^(13[0-9]|14[0-9]|15[0-9]|18[0-9])\d{8}$/i;
        if(reg.test(str)){
            $(this).next('i').css({
                'background-image':'url(../images/onCorrect.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
            $(this).next('i').text('手机号格式正确');
        }else{
            $(this).next('i').css({
                'background-image':'url(../images/onError.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
            $(this).next('i').text('手机号格式有误');
        }
    });


    
    //点击获取验证码并判断输入是否正确
    
    $('.yanzheng>span').click(function(){
        var yznum=Math.round(Math.random()*10000);
        $(this).text(yznum).css('fontSize', '24px');
    })
    $('input[name=yanzheng').blur(function(event) {
        if($(this).val()!=$(this).next().text()){
            $(this).next().next('i').text('验证码格式错误');
            $(this).next().next('i').css({
                'background-image':'url(../images/onError.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
        }else{
            $(this).next().next('i').text('验证码正确');
            $(this).next().next('i').css({
                'background-image':'url(../images/onCorrect.gif)',
                'background-position':'left'+' '+'center',
                'background-repeat':'no-repeat'
            });
        }
    });



    //提交表单
    $('input[type=button]').click(function(event) {
        //alert($('form div').find('i').css('background-image'))
        if($('form div').find('i').css('background-image')!='url("http://localhost/echongcheng/images/onCorrect.gif")' || $('input[name=xuanxiang]').attr('checked')!='checked'){
            //alert(1)
            return false;   
        }else{
            //alert(2)
            //window.location.href='http://www.baidu.com'
            $.cookie('user',$('input[name=user]').val());
            $.cookie('password',$('input[name=password]').val());
            window.location.href='denglu.html';
        }
    
    });

})


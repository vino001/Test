/* 
* @Author: anchen
* @Date:   2016-06-17 15:22:59
* @Last Modified by:   anchen
* @Last Modified time: 2016-06-17 15:24:05
*/

$(document).ready(function(){
    //alert(1)
});
/* 
* @Author: anchen
* @Date:   2016-06-21 22:02:02
* @Last Modified by:   anchen
* @Last Modified time: 2016-06-22 19:57:38
*/

$(document).ready(function(){
    // 引入头部
    $('#header').load('html/header_footer.html .header',function(){
        $('.nav').remove();
        //header_top鼠标滑过事件
        $('.ht_left li,.ht_right>li').hover(function(){
            $(this).children('a').css('color', '#FF6600');
        },function(){
            $(this).children('a').css('color', '');
        });

        //ht_r_fourth(我的E宠)鼠标滑过事件
        $('.ht_r_fourth').hover(function(){
            $('.mypet').css('display', 'block');
        },function(){
            $('.mypet').css('display', 'none');
        });
        $('.mypet li').hover(function(){
            $(this).find('a').css('color', 'red');
        },function(){
            $(this).find('a').css('color', '');
        });

        //ht_r_fifth(收藏我)鼠标滑过事件
        $('.ht_r_fifth').hover(function(){
            $('.shoucang').css('display', 'block');
        },function(){
            $('.shoucang').css('display', 'none');
        });
        $('.shoucang a').hover(function(){
            $(this).find('strong').css('background-position', '0 -114'+'px');
        },function(){
            $(this).find('strong').css('background-position', '');
        });
        //鼠标滑过骨头旋转
        $('.nav_second').nextAll('li').hover(function(){
            $(this).find('strong').css({
                '-webkit-transform': 'rotate(360deg)',
                '-moz-transform': 'rotate(360deg)',
                '-o-transform':'rotate(360deg)'
            });
            $(this).children('a').css('color', '#4c9605');
        },function(){
            $(this).find('strong').css({
                '-webkit-transform': '',
                '-moz-transform': '',
                '-o-transform':''
            });
            $(this).children('a').css('color', '');
        });



        //回到顶部
        $(document).scroll(function(){
            var scrollTop=document.documentElement.scrollTop||document.body.scrollTop;
            if(scrollTop>100){
                $('.rtbar').css('display', 'block');
            }else if(scrollTop<=100){
                $('.rtbar').css('display', 'none');
            }
            $('.rt_ten').click(function(event) {
                
                $(document).scrollTop(0);
            });
        })
        
        //右侧定位菜单点击购物车跳转页面   
        $('.rt_second').click(function(event) {
            window.location.href='http://www.baidu.com'
        });
    })
    $('#footer').load('html/header_footer.html .f_wrap')
    
    //获取ajax商品数据，拼接字符串显示所传过来的商品信息
    
    $.ajax({
        url: 'data/spxq.json',
        type: 'GET',
        dataType: 'json',
        success:function(res){
            //console.log(res)
            var $ID=$.cookie('goodId');
            //console.log($ID)
            var $Id_Num=$.cookie('goodId'+$ID)
            //alert($Id_Num)
            var arr=$Id_Num.split(',');
            //console.log(arr)
            var numbers=Number(arr[1]);
            //console.log(numbers);
            //console.log(res[$ID]);
            var html='';

            //购物车图标商品数量
            $('.shop a span').text($ID.length);




            var $Li=$('<li></li>');
            html+='<div class="check"><i><input type="checkbox"></i><span><img src='+res[$ID].url+' alt=""></span></div><div class="checktips"><p><span>(折扣)</span>'+res[$ID].bt+' </p><p class="fkxx">此商品须在06-26  12:20前完成付款，否则系统将自动删除该商品。</p></div>';
            html+='<div class="check_r"><div class="checknum"><span>'+numbers+'</span><p>有货</p></div><div class="checkmoney">￥<span>'+res[$ID].xj+'</span>/件</div><div class="check_delete"><span class="shoucang"><a href="#">【收藏】</a></span><span class="shanchu"><a href="#" class="sc">【删除】</a></span></div></div>';
            $Li.append(html);
            $('.ddlist ul').append($Li);

            //选择商品时，计入总价，并且使“去结算”按钮背景变色
            
            $('.check i input').click(function(){
                //console.log($(':checkbox:checked').length)
                //var countPrice = 0;
                if($(':checkbox:checked').length==0){
                    console.log("未选中任何商品")
                    $('.gopay span b').text('0.00');
                    $('input[value=去结算]').css('background', '');

                }else{
                    //alert(numbers*res[$ID].xj)
                    $('.gopay span b').text(numbers*res[$ID].xj);
                    $('input[value=去结算]').css('background', '#f40');
                }
            });
            //点击全选  事件
            $('.quanxuan input').click(function(){
                if($(this).is(':checked')){
                    //alert(1);
                    $('.gopay span b').text(numbers*res[$ID].xj);
                    $('input[value=去结算]').css('background', '#f40');
                    $('.check i input').attr('checked', 'checked');
                }else{
                    //alert(2);
                    $('.gopay span b').text('0.00');
                    $('input[value=去结算]').css('background', '');
                    $('.check i input').attr('checked', ' ');
                }
            });
        }

    })

    
    //点击删除按钮时，删除对应的商品，并且删除相应的cookie信息
    $('.ddlist ul').on('click',function(evt){
        //alert(evt.target.className)
        if(evt.target.className=='sc'){
            //alert(1)
            var $ID=$.cookie('goodId');
            $(evt.target).parent().parent().parent().parent().remove();
            $.cookie('goodId',null);
            $.cookie('goodId'+$ID,null);
        }
    });

    //点击“去结算”按钮事件
    $('.gopay input').click(function(event) {
        if($(':checkbox:checked').length>=1){
            alert('请选择支付方式')
        }else{
            alert('您还没选好购买的物品')
        }
    });
   



});
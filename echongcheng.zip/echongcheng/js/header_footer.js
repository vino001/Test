/* 
* @Author: anchen
* @Date:   2016-06-16 12:17:18
* @Last Modified by:   anchen
* @Last Modified time: 2016-06-23 15:31:23
*/

$(document).ready(function(){
    //header_top鼠标滑过事件
    $('.ht_left li,.ht_right>li').hover(function(){
        $(this).children('a').css('color', '#FF6600');
    },function(){
        $(this).children('a').css('color', '');
    });

    //ht_r_fourth(我的E宠)鼠标滑过事件
    $('.ht_r_fourth').hover(function(){
        $('.mypet').css('display', 'block');
    },function(){
        $('.mypet').css('display', 'none');
    });
    $('.mypet li').hover(function(){
        $(this).find('a').css('color', 'red');
    },function(){
        $(this).find('a').css('color', '');
    });

    //ht_r_fifth(收藏我)鼠标滑过事件
    $('.ht_r_fifth').hover(function(){
        $('.shoucang').css('display', 'block');
    },function(){
        $('.shoucang').css('display', 'none');
    });
    $('.shoucang a').hover(function(){
        $(this).find('strong').css('background-position', '0 -114'+'px');
    },function(){
        $(this).find('strong').css('background-position', '');
    });
    //鼠标滑过导航事件
    
    //鼠标滑过nav_first、nav_second事件
    $('.nav_first').hover(function(){
        $('.nav_first i').css({
            '-webkit-transform': 'rotate(180deg)',
            '-moz-transform': 'rotate(180deg)',
            '-o-transform':'rotate(180deg)'
        });
        $('.xl_nav_l').css('display', 'block');
        $('.xl_nav_r').css('display', 'none');
    },function(){
        $('.nav_first i').css({
            '-webkit-transform': '',
            '-moz-transform': '',
            '-o-transform':''
        });
        $('.xl_nav_l').css('display', '');
        $('.xl_nav_r').css('display', '');
    });
    $('.nav_second').hover(function(){
        $('.nav_second').children('a').children('b').css({
            '-webkit-transform': 'rotate(180deg)',
            '-moz-transform': 'rotate(180deg)',
            '-o-transform':'rotate(180deg)'
        });
        $('.xl_nav_l').css('display', 'none');
        $('.xl_nav_r').css('display', 'block');
    },function(){
        $('.nav_second').children('a').children('b').css({
            '-webkit-transform': '',
            '-moz-transform': '',
            '-o-transform':''
        });
        $('.xl_nav_l').css('display', '');
        $('.xl_nav_r').css('display', '');
    });
    //三级菜单显示隐藏
    $('.nav_second .xl_nav_r li').hover(function(){
        $(this).addClass('active');
        $(this).css('border-bottom', '1px solid #62a727');
        $(this).children('span').css('display', 'none');
        $(this).next('div').css('display', 'block');
    },function(){
        $(this).removeClass('active');
        $(this).css('border-bottom', '');
        $(this).children('span').css('display', '');
        $(this).next('div').css('display', 'none');
    });

    $('.mainbox_first').hover(function(){
        $(this).css('display', 'block');

        $(this).prev('li').addClass('active').css('border-bottom', '1px solid #62a727').children('span').css('display', 'none');;
    },function(){
        $(this).css('display', 'none');
        $(this).prev('li').removeClass('active').css('border-bottom', '').children('span').css('display', '');
    });

    //鼠标滑过骨头旋转
    $('.nav_second').nextAll('li').hover(function(){
        $(this).find('strong').css({
            '-webkit-transform': 'rotate(360deg)',
            '-moz-transform': 'rotate(360deg)',
            '-o-transform':'rotate(360deg)'
        });
        $(this).children('a').css('color', '#4c9605');
    },function(){
        $(this).find('strong').css({
            '-webkit-transform': '',
            '-moz-transform': '',
            '-o-transform':''
        });
        $(this).children('a').css('color', '');
    });



    //回到顶部
    $(document).scroll(function(){
        var scrollTop=document.documentElement.scrollTop||document.body.scrollTop;
        if(scrollTop>100){
            $('.rtbar').css('display', 'block');
        }else if(scrollTop<=100){
            $('.rtbar').css('display', 'none');
        }
        $('.rt_ten').click(function(event) {
            
            $(document).scrollTop(0);
        });
    })
    
    //右侧定位菜单点击购物车跳转页面   
    $('.rt_second').click(function(event) {
        window.location.href='http://www.baidu.com'
    });

    var userName=$.cookie('user');
    $('.ht_right li').eq(0).text('欢迎您，').css('color', '#f40');
    $('.ht_right li').eq(1).text(userName).css('color', '#f40');
});
























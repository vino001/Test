/* 
* @Author: anchen
* @Date:   2016-06-19 08:56:22
* @Last Modified by:   anchen
* @Last Modified time: 2016-06-23 22:24:20
*/

$(document).ready(function(){
    //引入公共头尾
    $('#header').load('html/header_footer.html .header',function(){
        //header_top鼠标滑过事件
        $('.ht_left li,.ht_right>li').hover(function(){
            $(this).children('a').css('color', '#FF6600');
        },function(){
            $(this).children('a').css('color', '');
        });

        //ht_r_fourth(我的E宠)鼠标滑过事件
        $('.ht_r_fourth').hover(function(){
            $('.mypet').css('display', 'block');
        },function(){
            $('.mypet').css('display', 'none');
        });
        $('.mypet li').hover(function(){
            $(this).find('a').css('color', 'red');
        },function(){
            $(this).find('a').css('color', '');
        });

        //ht_r_fifth(收藏我)鼠标滑过事件
        $('.ht_r_fifth').hover(function(){
            $('.shoucang').css('display', 'block');
        },function(){
            $('.shoucang').css('display', 'none');
        });
        $('.shoucang a').hover(function(){
            $(this).find('strong').css('background-position', '0 -114'+'px');
        },function(){
            $(this).find('strong').css('background-position', '');
        });
        //鼠标滑过导航事件
        
        //鼠标滑过nav_first、nav_second事件
        $('.nav_first').hover(function(){
            $('.nav_first i').css({
                '-webkit-transform': 'rotate(180deg)',
                '-moz-transform': 'rotate(180deg)',
                '-o-transform':'rotate(180deg)'
            });
            $('.xl_nav_l').css('display', 'block');
            $('.xl_nav_r').css('display', 'none');
        },function(){
            $('.nav_first i').css({
                '-webkit-transform': '',
                '-moz-transform': '',
                '-o-transform':''
            });
            $('.xl_nav_l').css('display', '');
            $('.xl_nav_r').css('display', '');
        });
        $('.nav_second').hover(function(){
            $('.nav_second').children('a').children('b').css({
                '-webkit-transform': 'rotate(180deg)',
                '-moz-transform': 'rotate(180deg)',
                '-o-transform':'rotate(180deg)'
            });
            $('.xl_nav_l').css('display', 'none');
            $('.xl_nav_r').css('display', 'block');
        },function(){
            $('.nav_second').children('a').children('b').css({
                '-webkit-transform': '',
                '-moz-transform': '',
                '-o-transform':''
            });
            $('.xl_nav_l').css('display', '');
            $('.xl_nav_r').css('display', '');
        });
        //三级菜单显示隐藏
        $('.nav_second .xl_nav_r li').hover(function(){
            $(this).addClass('active');
            $(this).css('border-bottom', '1px solid #62a727');
            $(this).children('span').css('display', 'none');
            $(this).next('div').css('display', 'block');
        },function(){
            $(this).removeClass('active');
            $(this).css('border-bottom', '');
            $(this).children('span').css('display', '');
            $(this).next('div').css('display', 'none');
        });

        $('.mainbox_first').hover(function(){
            $(this).css('display', 'block');

            $(this).prev('li').addClass('active').css('border-bottom', '1px solid #62a727').children('span').css('display', 'none');;
        },function(){
            $(this).css('display', 'none');
            $(this).prev('li').removeClass('active').css('border-bottom', '').children('span').css('display', '');
        });

        //鼠标滑过骨头旋转
        $('.nav_second').nextAll('li').hover(function(){
            $(this).find('strong').css({
                '-webkit-transform': 'rotate(360deg)',
                '-moz-transform': 'rotate(360deg)',
                '-o-transform':'rotate(360deg)'
            });
            $(this).children('a').css('color', '#4c9605');
        },function(){
            $(this).find('strong').css({
                '-webkit-transform': '',
                '-moz-transform': '',
                '-o-transform':''
            });
            $(this).children('a').css('color', '');
        });

        //回到顶部
        $(document).scroll(function(){
            var scrollTop=document.documentElement.scrollTop||document.body.scrollTop;
            if(scrollTop>100){
                $('.rtbar').css('display', 'block');
            }else if(scrollTop<=100){
                $('.rtbar').css('display', 'none');
            }
            $('.rt_ten').click(function(event) {
                
                $(document).scrollTop(0);
            });
        })
        
        //右侧定位菜单点击购物车跳转页面   
        $('.rt_second').click(function(event) {
            window.location.href=''
        });
        var userName=$.cookie('userName');
        if(userName!=null){
            $.cookie('userName',null,{path:'/'})
            $('.ht_right li').eq(0).text('欢迎您，').css('color', '#f40');
            $('.ht_right li').eq(1).text(userName).css('color', '#f40');
        }
        
    });
    
    $('#footer').load('html/header_footer.html .f_wrap');
//引入头尾——end


//左边——标签翻转动画
    var zd_timer1=null;
    var zd_Div_l_len=$('#left_box').children().size();
    //console.log(zd_Div_l_len)
    var nowBox=0;
    zd_timer1=setInterval(zd_Box_fanzhuan,3000);
    function zd_Box_fanzhuan(){
        if(nowBox==zd_Div_l_len-1){
            nowBox=0;
            $('#left_box').children().eq(zd_Div_l_len-1).slideUp('slow');
            $('#left_box').children().eq(nowBox).slideDown('slow');
        }else{
            nowBox++;
            $('#left_box').children().eq(nowBox-1).slideUp('slow');
            $('#left_box').children().eq(nowBox).slideDown('slow');
        }
    }


//右边——排队领礼包翻转动画
    var zd_timer2=null;
    var zd_Div_r_len=$('.kbpj_r_wrap').children().size();
    var nowDiv=0;
    //console.log(zd_Div_r_len)
    zd_timer2=setInterval(zd_Div_fanzhuan,3000)
    function zd_Div_fanzhuan(){
        if(nowDiv==zd_Div_r_len-1){
            nowDiv=0;
            $('.kbpj_r_wrap').children().eq(zd_Div_r_len-1).slideUp('slow');
            $('.kbpj_r_wrap').children().eq(nowDiv).slideDown('slow');
        }else{
            nowDiv++;
            $('.kbpj_r_wrap').children().eq(nowDiv-1).slideUp('slow');
            $('.kbpj_r_wrap').children().eq(nowDiv).slideDown('slow');
        }
    }


//天天惊喜
    /*$('.timer_out').hover(function(){
        $(this).css({
            'background-images':'url(../images/daysur_ico.png)',
            'background-position':'37px -263px',
            'background-repeat':'no-repeat',
            'bottom': '-52px',
            'height': '62px',
            'left':'0px'
        });
        $(this).parent().find('span').css({
            'color': '#fff',
            'font-weight': 'bold',
            'border-radius': '5px',
            'background': '#fe5400',
            'padding':'3px 20px'
        });
        $(this).parent().find('i').css('display', 'block');
    },function(){
        $(this).css({
            'background-images':'',
            'background-position':'',
            'background-repeat':'no-repeat',
            'bottom': '',
            'height': '',
            'left':''
        });
        $(this).parent().find('span').css({
            'color': '',
            'font-weight': '',
            'border-radius': '',
            'background': '',
            'padding':''
        });
        $(this).parent().find('i').css('display', '');
    })*/
    $('.timer_out').hover(function(){
        $(this).addClass('time_active');
        $(this).parent().siblings().find('em').removeClass('time_active');
        $(this).prev('i').css('display', 'block');
        $(this).parent().siblings().find('i').css('display', 'none');
        $(this).parent().find('span').addClass('time_span');
        $(this).parent().siblings().find('span').removeClass('time_span');
    },function(){
        $('timer_px').eq(0).find('em').addClass('time_active');
        $('timer_px').eq(0).find('span').addClass('time_span');
        $('timer_px').eq(0).find('i').css('display', 'block');
    });



    //index页面商品图片放大效果
    $('img').hover(function(){
        $(this).addClass('picactive');
    },function(){
        $(this).removeClass('picactive');
    })


    //轮播图下方：鼠标移入时显示纵向滚动条效果
    $('.kbpj_r_wrap').find('.gd').hover(function(){
        $(this).css('overflow-y', 'scroll');
    },function(){
        $(this).css('overflow-y', 'hidden');
    });

    //商品标题：鼠标移入时字体颜色变为蓝色----------------start
    $('.jsyg .sale_t>h3').find('a').hover(function(){
        $(this).css('color', 'blue');
    },function(){
        $(this).css('color', '');
    });

    $('.clxp_t_r h3 a').hover(function(){
        $(this).css('color', 'blue');
    },function(){
        $(this).css('color', '');
    });

    $('.clxp>a').hover(function() {
        $(this).css({
            'color':'blue',
            'text-decoration':'underline'
        })
    }, function() {
        $(this).css({
            'color':'',
            'text-decoration':''
        })
    });

    $('.pic_r h3>a').hover(function() {
        $(this).css('color', 'blue');
    }, function() {
        $(this).css('color', '');
    });

    $('.ggzl_title_r li a').hover(function(){
        $(this).css('color', 'blue');
    },function(){
        $(this).css('color', '');
    });

    $('.khpj_wrap h3>a').hover(function() {
        $(this).css('color', 'blue');
    }, function() {
        $(this).css('color', '');
    });


    //首页轮播图
    var nowPic=0;
    var timer_pic=null;
    var pic_len=$('.lunbo ul>li').size();
    //alert(pic_len)    //5
    var color_arr=['#e1f3ff','#bd3dec','#bbcdf5','#636fff','#fec01d'];
     $('.lunbo_wrap').css('background','#e1f3ff');
     $('.nav_second').css('background','#e1f3ff');
     $('.lunbo ul>li').eq(0).css('display','block')
    timer_pic=setInterval(picMove,3000);
    function picMove(){
        if(nowPic==pic_len-1){
            nowPic=0;
            $('.lunbo ul>li').eq(pic_len-1).stop().fadeOut('slow',function(){
                $('.lunbo ul>li').eq(0).stop().fadeIn('slow');
                $('.lunbo ul>li').eq(pic_len-1).removeClass('lunbo_active');
                $('.lunbo ul>li').eq(0).addClass('lunbo_active');
                $('.lunbo_wrap').css('background',color_arr[nowPic]);
                $('.nav_second').css('background',color_arr[nowPic]);
                $('.zy_lunbo_fenye span').eq(nowPic).attr('class','goClick').siblings().attr('class','')

            });
           
        }else{
            nowPic++;
            $('.lunbo ul>li').eq(nowPic-1).stop().fadeOut('slow',function(){
                $('.lunbo ul>li').eq(nowPic).stop().fadeIn('slow');
                $('.lunbo ul>li').eq(nowPic-1).removeClass('lunbo_active');
                $('.lunbo ul>li').eq(nowPic).addClass('lunbo_active');
                $('.lunbo_wrap').css('background',color_arr[nowPic]);
                $('.nav_second').css('background',color_arr[nowPic]);
                $('.zy_lunbo_fenye span').eq(nowPic).attr('class','goClick').siblings().attr('class','')

            });
        }

    }
    $('.zy_lunbo_fenye span').mouseover(function(){
        nowPic=$(this).index();
        $('.lunbo>ul>li').stop().fadeOut('slow');
        $(this).eq($(this).index()).attr('class','goClick').siblings().attr('class','')
        $('.lunbo>ul>li').eq($(this).index()).stop().fadeIn('slow');
        $('.lunbo_wrap').css('background',color_arr[nowPic]);
        $('.nav_second').css('background',color_arr[nowPic]);
    })

    $('.lunbo ul>li').hover(function(){
        clearInterval(timer_pic);
    },function(){
        timer_pic=setInterval(picMove,3000);
    })

    $('.lunbo_r div').hover(function(){
        $(this).css('left', '-10px');
    },function(){
        $(this).css('left', '');
    })





    //天天惊喜json 点击跳转详情页
    $.ajax({
        url:'data/spxq.json',
        type:'GET',
        success:function(res){
            //console.log(res)
            var html='';
            //console.log(res.length)
            for(var i=0;i<res.length;i++){
                html+='<li class="jsyg_same"><div class="sale_t"><a href="#"><img src='+res[i].url+' ></a><h3 id='+res[i].spxh+'><a href="#">'+res[i].title+'</a></h3></div>';
                html+='<div class="sale_b"><div class="sale_b_left"><p class="sbl_one"><span>￥</span>'+res[i].xj+'</p></div><p class="sb_two"><i>'+res[i].yj+'</i><b class="m1">仅剩'+res[i].kc+'罐</b></p></div>';
                html+='<div class="fr"><a href="#">点击收藏</a></div></li>';
            }
            $('.jsyg').append(html);
            $('.sale_t>a').click(function(event) {
                var $Id=$(this).next('h3').attr('id');
                //console.log($Id)
                $.cookie('goodId',$Id);
                window.location.href="spxq.html";
            });
        }
    });

    //首页图片懒加载
    $("img.lazy").lazyload({
        effect: "fadeIn",
        threshold: -100,
        placeholder:'images/loading4-4.gif'//用图片提前占位
    });




































































});
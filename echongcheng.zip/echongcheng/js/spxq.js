/* 
* @Author: anchen
* @Date:   2016-06-20 20:07:30
* @Last Modified by:   anchen
* @Last Modified time: 2016-06-22 21:36:12
*/

$(document).ready(function(){
    $('#header').load('html/header_footer.html .header',function(){
        $(document).ready(function(){
            //header_top鼠标滑过事件
            $('.ht_left li,.ht_right>li').hover(function(){
                $(this).children('a').css('color', '#FF6600');
            },function(){
                $(this).children('a').css('color', '');
            });

            //ht_r_fourth(我的E宠)鼠标滑过事件
            $('.ht_r_fourth').hover(function(){
                $('.mypet').css('display', 'block');
            },function(){
                $('.mypet').css('display', 'none');
            });
            $('.mypet li').hover(function(){
                $(this).find('a').css('color', 'red');
            },function(){
                $(this).find('a').css('color', '');
            });

            //ht_r_fifth(收藏我)鼠标滑过事件
            $('.ht_r_fifth').hover(function(){
                $('.shoucang').css('display', 'block');
            },function(){
                $('.shoucang').css('display', 'none');
            });
            $('.shoucang a').hover(function(){
                $(this).find('strong').css('background-position', '0 -114'+'px');
            },function(){
                $(this).find('strong').css('background-position', '');
            });
            //鼠标滑过导航事件
            
            //鼠标滑过nav_first、nav_second事件
            $('.nav_first').hover(function(){
                $('.nav_first i').css({
                    '-webkit-transform': 'rotate(180deg)',
                    '-moz-transform': 'rotate(180deg)',
                    '-o-transform':'rotate(180deg)'
                });
                $('.xl_nav_l').css('display', 'block');
                $('.xl_nav_r').css('display', 'none');
            },function(){
                $('.nav_first i').css({
                    '-webkit-transform': '',
                    '-moz-transform': '',
                    '-o-transform':''
                });
                $('.xl_nav_l').css('display', 'none');
                $('.xl_nav_r').css('display', 'none');
            });
            $('.nav_second').hover(function(){
                $('.nav_second').children('a').children('b').css({
                    '-webkit-transform': 'rotate(180deg)',
                    '-moz-transform': 'rotate(180deg)',
                    '-o-transform':'rotate(180deg)'
                });
                $('.xl_nav_l').css('display', 'none');
                $('.xl_nav_r').css('display', 'block');
            },function(){
                $('.nav_second').children('a').children('b').css({
                    '-webkit-transform': '',
                    '-moz-transform': '',
                    '-o-transform':''
                });
                $('.xl_nav_l').css('display', 'none');
                $('.xl_nav_r').css('display', 'none');
            });
            //三级菜单显示隐藏
            $('.nav_second .xl_nav_r li').hover(function(){
                $(this).addClass('active');
                $(this).css('border-bottom', '1px solid #62a727');
                $(this).children('span').css('display', 'none');
                $(this).next('div').css('display', 'block');
            },function(){
                $(this).removeClass('active');
                $(this).css('border-bottom', '');
                $(this).children('span').css('display', '');
                $(this).next('div').css('display', 'none');
            });

            $('.mainbox_first').hover(function(){
                $(this).css('display', 'block');

                $(this).prev('li').addClass('active').css('border-bottom', '1px solid #62a727').children('span').css('display', 'none');;
            },function(){
                $(this).css('display', 'none');
                $(this).prev('li').removeClass('active').css('border-bottom', '').children('span').css('display', '');
            });

            //鼠标滑过骨头旋转
            $('.nav_second').nextAll('li').hover(function(){
                $(this).find('strong').css({
                    '-webkit-transform': 'rotate(360deg)',
                    '-moz-transform': 'rotate(360deg)',
                    '-o-transform':'rotate(360deg)'
                });
                $(this).children('a').css('color', '#4c9605');
            },function(){
                $(this).find('strong').css({
                    '-webkit-transform': '',
                    '-moz-transform': '',
                    '-o-transform':''
                });
                $(this).children('a').css('color', '');
            });



            //回到顶部
            $(document).scroll(function(){
                var scrollTop=document.documentElement.scrollTop||document.body.scrollTop;
                if(scrollTop>100){
                    $('.rtbar').css('display', 'block');
                }else if(scrollTop<=100){
                    $('.rtbar').css('display', 'none');
                }
                $('.rt_ten').click(function(event) {
                    
                    $(document).scrollTop(0);
                });
            })
            
            //右侧定位菜单点击购物车跳转页面   
            // $('.rt_second').click(function(event) {
            //     window.location.href='http://www.baidu.com'
            // });
        });

        $('#footer').load('html/header_footer.html .f_wrap');    

        //导航隐藏
        $('.xl_nav_r').css('display', 'none');
    })
    
    // 接收首页传来的cookie（商品ID），获取当前商品并显示相关所有信息
    $.ajax({
        url:'data/spxq.json',
        type:'GET',
        success:function(res){
            //获取该商品的id
            var $spid=$.cookie('goodId');
            //alert($spid)
            //console.log(res[$spid].pic1)
            //放大镜部分
            $('#s_box').find('img').attr('src',res[$spid].url);
            $('#b_box_all').find('img').attr('src',res[$spid].url);
            $('.zs_list').children().children().eq(0).find('img').attr('src', res[$spid].zs_f);
            $('.zs_list').children().children().eq(1).find('img').attr('src', res[$spid].zs_s);
            $('.zs_list').children().children().eq(2).find('img').attr('src', res[$spid].zs_t);

            //商品详情部分
            var html='';
            html+='<h2><span>[多件优惠]</span>'+res[$spid].bt+'</h2><div style="color:#e3393c;padding:5px 0 0 20px">清洁牙齿 强健骨骼 补充营养 健康亮肤 高适口性</div><ul><li><span class="money_l">￥'+res[$spid].xj+'</span><span class="money_r"><i>市场价</i><b>￥'+res[$spid].yj+'</b></span></li></ul>';
            $('.gw_r').prepend(html);
            //编号部分
            var html1='';
            html1+='<p><span>编号：</span>144095'+res[$spid].spxh+'</p><p><span>已售：</span>8962支</p><p><span>赠送：</span>最多1E宠币</p><p><span>互动：</span><a href="#">咨询</a></p>';
            $('.canshu').append(html1);

            //商品详细图片
            
            for(var i in res[$spid]){
                var reg=/^pic/ig;
                if(reg.test(i)){
                    //console.log(i)
                    //console.log(res[$spid][i])
                    $div_img=$('<div><img src='+res[$spid][i]+' alt=""></div>');
                    $('.ad_r_b').append($div_img);
                }
            }

            //购物车加减按钮点击事件
            var sp_num=0;
            //var sp_arr=[];
            $('.add_buynum').click(function(event) {
                sp_num++;
                $(this).prev('input').val(sp_num);
                
                //sp_arr.push($spid);
                //console.log(sp_arr)
            });
            $('.lim_buynum').click(function(event) {
                if(sp_num<2){
                    $(this).next('input').val(1);
                }else{
                    sp_num--;
                }
                $(this).next('input').val(sp_num);
            });

            $('.gman input[name=jiaru]').click(function(event) {
                //alert(sp_num);
                var cookieName='goodId'+$spid;
                $.cookie(cookieName,$spid+','+sp_num);
                window.location.href="goumai.html"
            });
        }
    });
    

    
//放大镜
    $('.mark_box').mouseover(function(){
            $('.position_box').css('display','block');
            $('#b_box').css('display','block');
        });
        $('.mark_box').mouseout(function(){
            $('.position_box').css('display','none');
            $('#b_box').css('display','none');
        });
        $('.mark_box').mousemove(function(evt){
            //console.log(event)
            var left=evt.offsetX-$('.position_box')[0].offsetWidth/2;
            //console.log(left)
            if(left<0){
                left=0;
            }else if(left>$('#b_box')[0].offsetWidth-$('.position_box')[0].offsetWidth){
                left=$('#b_box')[0].offsetWidth-$('.position_box')[0].offsetWidth
            }
            //console.log(left)
            var left_px=left+"px"; 
            $('.position_box').css('left', left_px);
            //oS_position.style.left=left+'px';
            
            var top=evt.offsetY-$('.position_box')[0].offsetHeight/2;
            if(top<0){
                top=0;
            }else if(top>$('#s_box')[0].offsetHeight-$('.position_box')[0].offsetHeight){
                top=$('#s_box')[0].offsetHeight-$('.position_box')[0].offsetHeight
            }
            //console.log(top)
            var top_px=top+'px';
            $('.position_box').css('top', top_px);
            //oS_position.style.top=top+'px';
            //移动的比例  把X值和Y值换算成比例;
            var proportionX=left/($('#s_box')[0].offsetWidth-$('.position_box')[0].offsetWidth);
            var proportionY=top/($('#s_box')[0].offsetHeight-$('.position_box')[0].offsetHeight);
            //console.log(proportionX+':'+proportionY)
            //利用比例去算出大小不同的元素的偏移距离；
            
            var str_X=-proportionX*($('#b_box_all')[0].offsetWidth-$('#b_box')[0].offsetWidth)+'px';
            $('#b_box_all').css('left', str_X);
            
            var str_Y=-proportionY*($('#b_box_all')[0].offsetHeight-$('#b_box')[0].offsetHeight)+'px';
            $('#b_box_all').css('top', str_Y);
            
        });
    //点击图片列表，显示
    $('.zs_list ul li').click(function(event) {
        var $img=$(this).children('img').attr('src');
        //console.log($img)
        $('#s_box img').attr('src', $img);
        $('#b_box_all img').attr('src', $img);
    });  
    


































});
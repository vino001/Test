/* 
* @Author: anchen
* @Date:   2016-06-22 21:41:16
* @Last Modified by:   anchen
* @Last Modified time: 2016-06-23 09:17:48
*/

$(document).ready(function(){
    $('#header').load('html/header_footer.html .header',function(){
        $(document).ready(function(){
            //header_top鼠标滑过事件
            $('.ht_left li,.ht_right>li').hover(function(){
                $(this).children('a').css('color', '#FF6600');
            },function(){
                $(this).children('a').css('color', '');
            });

            //ht_r_fourth(我的E宠)鼠标滑过事件
            $('.ht_r_fourth').hover(function(){
                $('.mypet').css('display', 'block');
            },function(){
                $('.mypet').css('display', 'none');
            });
            $('.mypet li').hover(function(){
                $(this).find('a').css('color', 'red');
            },function(){
                $(this).find('a').css('color', '');
            });

            //ht_r_fifth(收藏我)鼠标滑过事件
            $('.ht_r_fifth').hover(function(){
                $('.shoucang').css('display', 'block');
            },function(){
                $('.shoucang').css('display', 'none');
            });
            $('.shoucang a').hover(function(){
                $(this).find('strong').css('background-position', '0 -114'+'px');
            },function(){
                $(this).find('strong').css('background-position', '');
            });
            //鼠标滑过导航事件
            
            //鼠标滑过nav_first、nav_second事件
            $('.nav_first').hover(function(){
                $('.nav_first i').css({
                    '-webkit-transform': 'rotate(180deg)',
                    '-moz-transform': 'rotate(180deg)',
                    '-o-transform':'rotate(180deg)'
                });
                $('.xl_nav_l').css('display', 'block');
                $('.xl_nav_r').css('display', 'none');
            },function(){
                $('.nav_first i').css({
                    '-webkit-transform': '',
                    '-moz-transform': '',
                    '-o-transform':''
                });
                $('.xl_nav_l').css('display', 'none');
                $('.xl_nav_r').css('display', 'none');
            });
            $('.nav_second').hover(function(){
                $('.nav_second').children('a').children('b').css({
                    '-webkit-transform': 'rotate(180deg)',
                    '-moz-transform': 'rotate(180deg)',
                    '-o-transform':'rotate(180deg)'
                });
                $('.xl_nav_l').css('display', 'none');
                $('.xl_nav_r').css('display', 'block');
            },function(){
                $('.nav_second').children('a').children('b').css({
                    '-webkit-transform': '',
                    '-moz-transform': '',
                    '-o-transform':''
                });
                $('.xl_nav_l').css('display', 'none');
                $('.xl_nav_r').css('display', 'none');
            });
            //三级菜单显示隐藏
            $('.nav_second .xl_nav_r li').hover(function(){
                $(this).addClass('active');
                $(this).css('border-bottom', '1px solid #62a727');
                $(this).children('span').css('display', 'none');
                $(this).next('div').css('display', 'block');
            },function(){
                $(this).removeClass('active');
                $(this).css('border-bottom', '');
                $(this).children('span').css('display', '');
                $(this).next('div').css('display', 'none');
            });

            $('.mainbox_first').hover(function(){
                $(this).css('display', 'block');

                $(this).prev('li').addClass('active').css('border-bottom', '1px solid #62a727').children('span').css('display', 'none');;
            },function(){
                $(this).css('display', 'none');
                $(this).prev('li').removeClass('active').css('border-bottom', '').children('span').css('display', '');
            });

            //鼠标滑过骨头旋转
            $('.nav_second').nextAll('li').hover(function(){
                $(this).find('strong').css({
                    '-webkit-transform': 'rotate(360deg)',
                    '-moz-transform': 'rotate(360deg)',
                    '-o-transform':'rotate(360deg)'
                });
                $(this).children('a').css('color', '#4c9605');
            },function(){
                $(this).find('strong').css({
                    '-webkit-transform': '',
                    '-moz-transform': '',
                    '-o-transform':''
                });
                $(this).children('a').css('color', '');
            });



            //回到顶部
            $(document).scroll(function(){
                var scrollTop=document.documentElement.scrollTop||document.body.scrollTop;
                if(scrollTop>100){
                    $('.rtbar').css('display', 'block');
                }else if(scrollTop<=100){
                    $('.rtbar').css('display', 'none');
                }
                $('.rt_ten').click(function(event) {
                    
                    $(document).scrollTop(0);
                });
            })
            
            //右侧定位菜单点击购物车跳转页面   
            // $('.rt_second').click(function(event) {
            //     window.location.href='http://www.baidu.com'
            // });
        });

        $('#footer').load('html/header_footer.html .f_wrap');    

        //导航隐藏
        $('.xl_nav_r').css('display', 'none');
    })

    //倒计时-------------------------------------------------start
    //需求：判断两个日期之间相差的天数

    /*
        功能：计算两个日期差
        参数：
            startTime：起始时间
            endTime:   结束时间
    */
    function getDiff(startTime,endTime){
        var startMs = startTime.getTime();  //起始时间的毫秒数
        var endMs = endTime.getTime();  //结束时间的毫秒数
        var diff = endMs-startMs; //时间差
        var ms = diff%1000; //剩余的毫秒；
        var ss = parseInt(diff/1000%60); //剩余的秒数
        var mm = parseInt(diff/1000/60%60); //剩余的分钟
        var hh = parseInt(diff/1000/60/60%24); //剩余的小时
        var day = parseInt(diff/1000/60/60/24);  //天数
    
        if(diff>0){
            var format =  day + "天" + hh + "小时" + mm + "分钟" + ss + "秒" + ms + "毫秒";
        }else{
            var format =  0 + "天" + 0 + "小时" + 0 + "分钟" + 0 + "秒" + 0 + "毫秒";
        }
        
        return format;
    }
    var end = new Date("2016/6/24 23:59:59");  //未来的时间
    var termId = setInterval(function(){
        //document.body.innerHTML = "";
        var start = new Date();  //当前的时间
        //document.write(getDiff(start,end));
        $('.jrfq_djs i').text(getDiff(start,end));

        //console.log(end.getTime()-start.getTime());
        if(end.getTime()-start.getTime()<=0){
            clearInterval(termId);  
        };
    
    },1);

    //倒计时-------------------------------------------------end

    





});